(function IIFE() {
    'use strict';
    console.log(this);      // returns undefined
    var one = function levelOne() {
        console.log(this);
    };
    one(this);
}());