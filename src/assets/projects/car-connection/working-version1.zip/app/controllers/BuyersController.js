(function () {
	"use strict";
    function buyersController() {
        var string = "Hello world";
    }
});