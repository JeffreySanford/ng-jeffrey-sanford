/*global angular:false, otherVar:true*/
(function () {
	"use strict";
	var CarConn = angular.module('CarConn', ['ngRoute', 'ngAnimate']);

	CarConn.config(function ($routeProvider) {
		$routeProvider
			.when('/', {
            /*  Landing page */
				controller: 'MainController',
				templateUrl: 'app/views/partials/mainView.html',           
            })
            .when('/find', {
            /*  Will list all the resource members */
                controller: 'MainController',
                templateUrl: 'app/views/partials/find.html'
            })
        
            .when('/about', {
            /*  Will list all the resource members */
                controller: 'MainController',
                templateUrl: 'app/views/partials/about.html'
            })
        
			.when('/resources', {
            /*  Will list all the resource members */
                controller: 'ResourcesController',
                templateUrl: 'app/views/partials/resources.html'
            })
            .when('/resources/:resourceID', {
            /*  Will list individual resource members by ID field */
                controller: 'ResourcesController',
                templateURL: 'app/views/oneResource.html'
            })
        
			.when('/buyers', {
            /*  Will list all the buyer members */
                controller: 'BuyersController',
                templateUrl: 'app/views/buyers.html'
            })
            
            .when('/buyers/:buyerID', {
            /*  Will list individual buyer memebers by BuyerID field */
                controller: 'BuyersController',
                templateURL: 'app/views/buyer.html'
            })

			.otherwise({redirectTo: '/admin' });
            /*  Redirect all other queries to the admin section */
    });

    CarConn.controller('MainController', function MainController($scope, $http) {
        $http.get("js/json/owners.json")
            .success(function (responce) {
                $scope.owners = responce;
            });
        });

    CarConn.controller('ResourcesController', function MainController($scope, $http) {
        $http.get("js/json/owners.json")
            .success(function (responce) {
                $scope.owners = responce;
            });
    });
}());
