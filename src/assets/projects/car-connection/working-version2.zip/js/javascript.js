function init () {
    alert ('loaded');
}
    