(function () {
    "use strict";
    function MainController($scope, $http) {
        $http.get("js/json/owners.json")
            .success(function (responce) {
                $scope.owners = responce;
            });
    }
}());
    /* Reference: 
                    Used in:
                                find.html
                                about.html
                    ng-controller="mainController" 
    */