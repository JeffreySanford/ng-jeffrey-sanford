(function () {
    "use strict";
    function BuyersController($scope, $http) {
        $http.get("js/json/owners.json")
            .success(function (responce) {
                $scope.owners = responce;
            });
    }
}());